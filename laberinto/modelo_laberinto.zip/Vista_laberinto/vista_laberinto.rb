# encoding:utf-8
# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

module Vista_laberinto

  require_relative './../Controlador_laberinto/estado_juego.rb'
  require_relative './../Controlador_laberinto/controlador.rb'
  require_relative './../Modelo_laberinto/direccion.rb'

class Vista_laberinto

  def initialize(controlador)
    @controlador = controlador
  end

  def menu_usuario
    case @controlador.estado
    when Controlador_laberinto::Estado_juego::EN_ENTRADA_LABERINTO

      puts "Intoduzca el número de vidas (entre 1 y 10) antes de entrar en el laberinto"
      vidas=gets.chomp.to_i

      while (vidas < 1 || vidas > 10)
        puts "Intoduzca el número de vidas (entre 1 y 10) antes de entrar en el laberinto"
        vidas=gets.chomp.to_i
      end
      @controlador.entrar(vidas)

    when Controlador_laberinto::Estado_juego::DENTRO_VIVO

      informe_dentro(@controlador.habitacion_usuario, @controlador.vidas)

      puts "Pulse enter para continuar"
      st= gets.chomp
      @movimiento=@controlador.intentar_avanzar()

      puts @movimiento

    when Controlador_laberinto::Estado_juego::EN_SALIDA_LABERINTO

      informe_final (@controlador.vidas)
      exit 0

    when Controlador_laberinto::Estado_juego::DENTRO_MUERTO

      informe_final (@controlador.vidas)
      exit 0

    end

    self.menu_usuario
  end

  def informe_dentro (habitacion, vidas)
    puts ("habitacion: " + habitacion.num_habitacion.to_s + " . Vidas: " + vidas.to_s)
  end

  def informe_final (vidas)
    puts (vidas)
  end

end

end